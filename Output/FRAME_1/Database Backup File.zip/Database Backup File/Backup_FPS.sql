use fps_development 
GO
sp_BackupDatabaseFPS 'fps_development', 'F'
GO
QUIT